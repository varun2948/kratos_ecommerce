@extends('layout.app')

@section('content')

<div class="thank-you-section">
       <h1>Thank you for <br> Your Order!</h1>
       <p>A confirmation email was sent</p>
       <div class="spacer"></div>
       <div>
           <a href="https://laravelecommerceexample.ca" class="button">Home Page</a>
       </div>
   </div>

@endsection

