<footer class="site-footer footer-opt-2">



                <div class="footer-top full-width">

                    <div class="container">

                        <div class="row">

                            <div class="col-md-6">

                                <div class="newsletter-title">

                                    <h3 class="h3-newsletter">Sign up to Newsletter</h3>

                                    <span class="span-newsletter">Recevie Rs.50 Coupon for Shopping.</span>

                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="newsletter-form">

                                    <form id="newsletter-validate-detail" class="form subscribe">

                                        <div class="control">

                                            <input type="email" placeholder="Enter your email address" id="newsletter" name="email" class="input-subscribe">

                                            <button type="submit" title="Subscribe" class="btn subscribe">

                                                <span>Sign Up</span>

                                            </button>

                                        </div>

                                    </form>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="footer-column equal-container">

                    <div class="container">

                        <div class="row">

                            <div class="col-md-4 col-sm-6 equal-elem">

                                <h3 class="title-of-section">About Us</h3>

                                <div class="contacts">

                                    <p class="contacts-info">We Provide All Kinds Of Groceries,Accessories,Gadgets,Home-Appliances & Many More.</p>

                                    <span class="contacts-info info-address ">Samakhusi</span>

                                    <span class="contacts-info info-phone">9845662948</span>

                                    <span class="contacts-info info-support">deepak.pradhan048@gmail.com</span>

                                    <div class="socials">

                                        <a href="#" class="social"><i class="fa fa-twitter" aria-hidden="true"></i></a>

                                        <a href="#" class="social"><i class="fa fa-facebook" aria-hidden="true"></i></a>

                                        <a href="#" class="social"><i class="fa fa-pinterest" aria-hidden="true"></i></a>

                                        <a href="#" class="social"><i class="fa fa-instagram" aria-hidden="true"></i></a>

                                        <a href="#" class="social"><i class="fa fa-vimeo" aria-hidden="true"></i></a>

                                        <a href="#" class="social"><i class="fa fa-youtube" aria-hidden="true"></i></a>

                                    </div>

                                </div>

                            </div>

                            <div class="col-md-2 col-sm-6 equal-elem">

                                <div class="links">

                                <h3 class="title-of-section">My account</h3>

                                <ul>

                                    <!-- <li><a href="#">Sign In</a></li> -->

                                    <li><a href="{{url('/cart')}}">View Cart</a></li>

                                    <li><a href="{{url('/contact')}}">Contact us</a></li>

                                </ul>

                                </div>

                            </div>

                            <!-- <div class="col-md-2 col-sm-6 equal-elem">

                                <div class="links">

                                <h3 class="title-of-section">Information</h3>

                                <ul>

                                    <li><a href="#">Specials</a></li>

                                    <li><a href="#">New products</a></li>

                                    <li><a href="#">Best sellers</a></li>

                                    <li><a href="#">Our stores</a></li>

                                    <li><a href="#">Contact us</a></li>


                                </ul>

                                </div>

                            </div> -->


                        </div>

                    </div>

                </div>

                <div class="copyright full-width">

                     <div class="container">

                         <div class="copyright-right">

                            © Copyright 2019<span> Deepak</span>. All Rights Reserved.

                        </div>


                     </div>

                </div>

        </footer>
